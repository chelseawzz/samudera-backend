<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Samudata - Sistem Manajemen Data DKP Jawa Timur</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .hero-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body class="hero-bg min-h-screen flex items-center justify-center">
    <div class="text-center">
        <div class="mb-8">
            <i class="fas fa-water text-white text-6xl mb-4"></i>
            <h1 class="text-white text-5xl font-bold mb-4">Samudata</h1>
            <p class="text-white text-xl opacity-90 mb-8">Sistem Manajemen Data DKP Jawa Timur</p>
        </div>
        
        <div class="space-y-4">
            <a href="login.html" class="inline-block bg-white text-blue-600 font-semibold py-3 px-8 rounded-lg hover:bg-opacity-90 transition duration-200">
                <i class="fas fa-sign-in-alt mr-2"></i>Masuk ke Sistem
            </a>
            <p class="text-white opacity-70 text-sm">Silakan login untuk mengakses sistem manajemen data</p>
        </div>
    </div>

    <script>
        // Auto redirect to login if not logged in
        if (!localStorage.getItem('isLoggedIn')) {
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        } else {
            // If already logged in, redirect to dashboard
            window.location.href = 'dashboard.html';
        }
    </script>
</body>
</html>

